# Database and Storage

## Purpose
Module 2 is intentionally stateless for business data. It reuses existing services where possible.

## Runtime Data
- Uploaded images (temporary)
- Parsed property object
- Google Maps enrichment
- Formatted listing
- WhatsApp message response

## Storage Strategy
Temporary uploads:
- Store only for request processing.
- Delete after successful WhatsApp delivery or timeout.

Future Integration
- Optional link to Module 1 PID.
- Optional archive of generated listing.
- No permanent database required in Phase 1.

## Image Lifecycle
Upload → Validate → Send to WhatsApp → Cleanup.

## Security
Never persist WhatsApp access tokens, temporary media IDs, or raw uploads longer than required.
