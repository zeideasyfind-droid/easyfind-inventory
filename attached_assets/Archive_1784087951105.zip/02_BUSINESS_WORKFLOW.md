# Business Workflow

## Current
Owner shares details → Broker edits text → Opens Maps → Identifies society → Formats manually → Selects images → Sends WhatsApp.

## Target
Owner message + Images
↓
Paste once
↓
Generate
↓
Receive one WhatsApp-ready media album

## Benefits
- Consistent listing format
- Lower manual effort
- Faster onboarding
- Reduced formatting errors
