# Formatter Engine

## Objective
Produce a deterministic EasyFind listing.

## Pipeline
Raw Message
→ Parser
→ Standardizer
→ Maps Enrichment
→ Community Detection
→ Template Builder
→ Validator
→ Final Caption

## Community Rules

### Gated
Community: Gated
Society: <Society Name>
Maps:
<Google Maps URL>

### Semi-Gated
Community: Semi-Gated
Society: <Apartment Name>
Maps:
<Google Maps URL>

### Standalone
Community: Standalone
Landmark:
<Nearest Landmark>
Maps:
<Google Maps URL>

Never expose the exact standalone property address.

## Validation
- Mandatory fields present.
- Formatting matches EasyFind template.
- No invented values.
