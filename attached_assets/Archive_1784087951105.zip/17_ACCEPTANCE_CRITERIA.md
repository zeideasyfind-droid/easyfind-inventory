# Acceptance Criteria

## Functional
- Paste a single raw owner message (including any Google Maps URL).
- Upload one or more images.
- Preview is generated without manual editing.
- Community is classified correctly (Gated / Semi-Gated / Standalone / Unknown).
- Listing follows the EasyFind template exactly.
- Images retain original order.
- WhatsApp Cloud API sends one media album with one caption.

## Quality
- No secrets exposed to the browser.
- Formatter is deterministic.
- Existing Module 1 remains unaffected.

## Exit Criteria
Module 2 is accepted only when a broker can complete the workflow end-to-end without manually reformatting the listing.
