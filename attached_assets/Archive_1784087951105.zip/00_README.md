# Module 2 – Property Publishing Engine

## Purpose
Module 2 converts a raw owner property message and uploaded images into an EasyFind-formatted listing and delivers it as a single WhatsApp media message.

## Scope
- Independent from Module 1 (Inventory Engine)
- Reuses shared backend utilities where appropriate
- Rule-based formatting
- Google Maps enrichment
- WhatsApp Cloud API delivery

## High-level Flow
Paste owner message + Upload images
→ Parse raw text
→ Detect Google Maps URL
→ Google Places enrichment
→ Community detection
→ EasyFind formatter
→ Preview
→ WhatsApp Cloud API
→ One media album + one caption
