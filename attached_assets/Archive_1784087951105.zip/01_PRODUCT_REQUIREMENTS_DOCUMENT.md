# Product Requirements Document

## Problem
Publishing newly onboarded properties into the internal WhatsApp inventory is manual, repetitive, and time-consuming.

## Goal
Reduce the workflow to:
1. Paste the complete owner message (including any Google Maps link).
2. Upload images.
3. Click Generate & Send.

## Functional Requirements
- Single text input (no separate Maps field).
- Multiple image upload.
- Automatic Maps URL detection.
- Deterministic parsing and formatting.
- Google Places enrichment.
- Community classification (Gated, Semi-Gated, Standalone).
- WhatsApp Cloud API delivery as one media group with one caption.
- Preview before send.
- Server-side handling of API keys.

## Non-functional Requirements
- No hardcoded secrets.
- Fast response.
- Graceful failure handling.
- Extensible formatter templates.
