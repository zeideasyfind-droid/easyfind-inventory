# Configuration

Environment Variables

GOOGLE_MAPS_API_KEY
WHATSAPP_ACCESS_TOKEN
WHATSAPP_PHONE_NUMBER_ID
WHATSAPP_RECIPIENT_NUMBER
APP_ENV
LOG_LEVEL

## Principles
- All secrets from environment.
- No hardcoded credentials.
- Separate dev/staging/prod configs.

## Cloud Run
Inject environment variables through Cloud Run configuration or Secret Manager.
