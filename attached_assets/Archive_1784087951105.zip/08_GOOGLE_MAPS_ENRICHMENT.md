# Google Maps Enrichment

## Input
The backend scans the pasted owner message and automatically extracts the first valid Google Maps URL.

## Enrichment
Call Google Places APIs to obtain:
- Place name
- Formatted address
- Place types
- Coordinates (optional)

## Classification
If place represents a named apartment/society:
- Community = Gated or Semi-Gated (according to configured rules)
- Display society name.

If no society/apartment is identified:
- Community = Standalone
- Derive a nearby landmark from Places data.
- Display 'Landmark' instead of society name.

## Failure Handling
If Maps lookup fails:
- Continue formatting.
- Mark community as Unknown.
- Preserve original Maps URL if available.
