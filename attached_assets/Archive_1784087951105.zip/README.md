# Diagrams

Recommended diagrams:
- User flow
- Component architecture
- Sequence diagram
- Backend processing pipeline
- WhatsApp delivery flow
- Google Maps enrichment flow
- Deployment architecture
