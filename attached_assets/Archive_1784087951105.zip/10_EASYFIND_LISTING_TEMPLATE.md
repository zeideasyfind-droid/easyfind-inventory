# EasyFind Listing Template

The formatter must produce a deterministic template.

Example:

2 BHK | Semi Furnished

Rent: ₹45,000 + Maintenance
Deposit: ₹2,00,000

Area: 1200 Sq. Ft.
Bathrooms: 2
Balcony: 1

Available: Immediate

Community: Gated
Society:
Prestige Lakeside Habitat

Maps:
https://maps.google.com/...

Brokerage Applicable

Rules:
- Consistent spacing.
- Fixed field order.
- Never invent values.
- Omit optional fields when unavailable.
- Images are attached separately as one WhatsApp media album.
