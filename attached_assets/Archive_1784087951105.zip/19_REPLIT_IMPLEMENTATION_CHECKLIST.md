# Replit Implementation Checklist

## UI
- [ ] Add Module 2 card below Inventory Engine.
- [ ] Add multiline owner message input.
- [ ] Add drag-and-drop image uploader.
- [ ] Add preview panel.
- [ ] Add Send button.

## Backend
- [ ] Build parser service.
- [ ] Auto-detect Google Maps URL.
- [ ] Integrate Google Places API.
- [ ] Implement community detection.
- [ ] Implement formatter.
- [ ] Implement WhatsApp Cloud API sender.
- [ ] Return preview endpoint.
- [ ] Return send endpoint.

## Validation
- [ ] Functional tests pass.
- [ ] Integration tests pass.
- [ ] No regressions in Module 1.
- [ ] Commit and push.
