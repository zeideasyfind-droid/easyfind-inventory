# WhatsApp Delivery Engine

## Objective
Deliver one outbound WhatsApp media album containing:
- Uploaded images
- One caption (EasyFind formatted listing)

Workflow:
Browser
→ Backend
→ Upload media to WhatsApp Cloud API
→ Collect media IDs
→ Create media group payload
→ Attach caption to first image
→ Send to configured EasyFind Business number

Requirements:
- Preserve image order.
- Retry transient API failures.
- Return WhatsApp message ID.
- Never expose access tokens to frontend.

Failure:
- If sending fails, return formatted listing to UI so it can be copied manually.
