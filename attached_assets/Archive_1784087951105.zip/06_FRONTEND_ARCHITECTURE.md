# Frontend Architecture

## Components
- PropertyPublishingCard
- ImageUploader
- OwnerMessageInput
- PreviewPanel
- PublishButton
- StatusBanner

## Workflow
Paste owner message
↓
Drop images
↓
Generate Preview
↓
Preview returned from backend
↓
Send
↓
Display WhatsApp message ID and success/failure.

The frontend contains no business logic beyond validation and rendering.
