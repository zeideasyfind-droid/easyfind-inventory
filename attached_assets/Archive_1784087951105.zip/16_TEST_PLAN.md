# Test Plan

## Functional
✓ Gated property
✓ Semi-Gated property
✓ Standalone property
✓ Missing Maps URL
✓ Invalid Maps URL
✓ Single image
✓ Multiple images (30+)
✓ Long owner message
✓ Unicode characters

## Integration
✓ Google Maps success
✓ Google Maps failure
✓ WhatsApp upload
✓ WhatsApp send
✓ Retry after failure

## Regression
✓ Formatter output unchanged
✓ Existing Module 1 unaffected

## Acceptance
A broker should complete:
1. Paste owner message.
2. Upload images.
3. Generate preview.
4. Send.
in under one minute.
