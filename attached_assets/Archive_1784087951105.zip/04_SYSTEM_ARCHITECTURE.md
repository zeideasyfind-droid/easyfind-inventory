# System Architecture

Frontend
- Collect owner message
- Upload images
- Display preview
- Trigger publish

Backend
- Property parser
- Maps enrichment service
- Community detector
- Formatter engine
- WhatsApp delivery service

Sequence

Browser
→ Backend
→ Parse
→ Google Places
→ Formatter
→ Preview
→ WhatsApp Cloud API
→ Success

Design Principles
- Server-side integrations only
- Rule-based formatting
- Modular services
- Future-ready for Module 3
