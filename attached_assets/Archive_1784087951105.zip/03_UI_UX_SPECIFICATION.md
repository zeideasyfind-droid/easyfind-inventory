# UI / UX Specification

## Layout

Existing Module 1 (Inventory)

--------------------------------

Module 2 – Property Publishing

[ Upload Images ]
(Drag & Drop)

[ Paste Complete Owner Message ]
(multiline text area)

[ Generate Preview ]

Preview Panel

[ Send to WhatsApp ]

## States
- Idle
- Parsing
- Maps enrichment
- Formatting
- Sending
- Success
- Error

## Validation
- Text required
- At least one image
- Maps URL optional but auto-detected if present
