# Error Handling

## Validation Errors
- Missing owner message → HTTP 400
- No images → HTTP 400
- Unsupported image type → HTTP 415

## Google Maps
If URL missing:
- Continue without enrichment.

If lookup fails:
- Community = Unknown
- Preserve original Maps URL
- Continue formatting.

## WhatsApp
If upload fails:
- Return formatted listing and error.
- Do not lose generated caption.

If send fails:
- Return preview with API error.
- Allow retry without reformatting.

## Logging
Log request ID, processing stage, upstream failures, and response time.
Never log secrets or access tokens.
