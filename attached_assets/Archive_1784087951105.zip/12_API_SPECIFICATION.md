# API Specification

POST /publish/preview

Request:
- multipart/form-data
- owner_message: string
- images[]: files

Response:
{
  "success": true,
  "preview": "...formatted listing...",
  "community": "Gated",
  "society": "Prestige Lakeside Habitat"
}

POST /publish/send

Request:
- owner_message
- images[]

Response:
{
  "success": true,
  "message_id": "<whatsapp_message_id>",
  "image_count": 12,
  "delivery": "sent"
}

Errors:
400 Invalid input
422 Validation failure
502 Google Maps / WhatsApp upstream failure
500 Internal server error
