# Community Detection

## Objective
Classify every property into one of three EasyFind community types.

### Gated
Criteria:
- Recognized residential society/township.
- Named gated community from Google Places.
Display:
Community: Gated
Society: <Society Name>
Maps:
<Google Maps URL>

Example:
Community: Gated
Society: Prestige Lakeside Habitat
Maps:
https://maps.google.com/...

### Semi-Gated
Criteria:
- Apartment/building with identifiable name but not a large gated township.
Display:
Community: Semi-Gated
Society: SRR Aqua
Maps:
<Google Maps URL>

### Standalone
Criteria:
- Independent house, villa, builder floor, or property without a recognized society.
Display:
Community: Standalone
Landmark: Near HSR BDA Complex
Maps:
<Google Maps URL>

Rules:
- Never expose exact standalone address.
- Prefer nearest public landmark.
- If uncertain, return Community: Unknown and preserve Maps URL.
