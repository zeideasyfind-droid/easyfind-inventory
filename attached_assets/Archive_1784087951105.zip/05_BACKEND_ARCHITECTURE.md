# Backend Architecture

## Responsibilities
- Accept publish requests.
- Parse raw owner message.
- Extract Google Maps URL automatically.
- Enrich property using Google Places API.
- Detect community type.
- Build EasyFind listing via rule-based formatter.
- Upload images to WhatsApp Cloud API.
- Send one media album with one caption.

## Suggested Services
- parser_service.py
- maps_service.py
- community_service.py
- formatter_service.py
- whatsapp_service.py
- validation_service.py

## API
POST /publish/preview
POST /publish/send

The frontend never calls Google Maps or WhatsApp directly.
All API keys remain server-side.
